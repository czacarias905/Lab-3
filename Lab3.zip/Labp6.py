#Cecilia Zacarias
#01/30/2020

#This program computes MPG for a car. User will be prompt to enter number of miles driven and gallons used.Printed with the awnser and a nice message

Mdriven = int(input("What are the miles driven?"))

gUsed = int(input("What are the gallons used?"))

MPG = Mdriven/gUsed

print("The Miles per Gallon is", MPG)
