#Cecilia Zacarias
#01/30/2020

#This program computes area of a circle and prompts user to enter radius of a circle and prints a nice message with anwser

radius = int(input("Hi,What is the radius of the circle "))
PI = 3.14
area = PI*radius*radius

print("The anwser is", area)
