#Cecilia Zacarias
#01/30/2020

#This program asks the user for their name and then greets them with their name.

# This block shows the variable for name
myName = input("What is your name? ")

# This block prints greeting and name
print("Hi",myName,User)
