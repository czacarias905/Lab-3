#Cecilia Zacarias
#01/30/2020

#This program asks the user for their name and then greets them modified for one specific person and whoever else access

myName = input("What is your name? ")

if myName == "Robyn":
    #stuff to do if it's robyn
    print("Welcome")
else:
    print("Access denied")
    #stuff to do if it's not robyn
    pass
print("Hi",myName)
