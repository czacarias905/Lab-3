#Cecilia Zacarias
#01/30/2020

#This program will convert degrees fahrenheit to degrees Celsius

fahrenheit = float(input("Hi what is the degree outside in farenheit?"))

Celsius = fahrenheit-32 * 5/9

print(fahrenheit, "Fahrenheit" , "is also", Celsius,"celsius")
